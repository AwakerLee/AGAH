import numpy as np
import torch
import clip
from PIL import Image
import torch.optim as optim
import torch.utils.data
import torchvision
import torchvision.models as models
import torch.backends.cudnn as cudnn
from torch.autograd import Variable
from args import config
import scipy.io as scio
import scipy.sparse as sp
import torch.nn.functional as F
import h5py
# device = "cuda" if torch.cuda.is_available() else "cpu"
# model, preprocess = clip.load("ViT-B/32", device=device)
#
#
# image = preprocess(Image.open("dog.png")).unsqueeze(0).to(device)
# print(image)
# text = clip.tokenize(["a redenvelope","a dog"]).to(device)
#
# with torch.no_grad():
#     image_features = model.encode_image(image)
#     text_features = model.encode_text(text)
#     SIM = torch.cosine_similarity(image_features,text_features)
#     print(SIM)
#     logits_per_image, logits_per_text = model(image, text)
#     probs = logits_per_image.softmax(dim=-1).cpu().numpy()
#
# print("Label probs:", probs)  # prints: [[0.9927937  0.00421068 0.00299572]]


if __name__ == '__main__':
    # pass
#     mirflickr = h5py.File(config.IMG_DIR, 'r', libver='latest', swmr=True)
#     img= mirflickr['IAll'][0]
#     print(img)
#     img = Image.fromarray(np.transpose(img, (2, 1, 0)))
#     mirflickr.close()
#     print(img)

    # def gen_adj(A):
    #     D = torch.pow(A.sum(1).float(), -0.5)
    #     D = torch.diag(D)
    #     adj = torch.matmul(torch.matmul(A, D).t(), D)
    #     return adj
    #
    # # print(label_set.shape)
    txt_set = scio.loadmat('E:/BaiduNetdiskDownload/Cleared-Set/mirflickr/mirflickr25k-yall.mat')
    batch_txt = txt_set['YAll'][0:8, :]
    txt = torch.FloatTensor(batch_txt)
    F_T = F.normalize(txt, dim=1)
    S_T = F_T.mm(F_T.t())
    print(S_T)
    mean = torch.mean(S_T)
    max = torch.max(S_T)
    min = torch.min(S_T)

    s_h, s_mean, s_max, s_min =  torch.mean(S_T[S_T > mean]), mean, max, min
    print(s_h)
    print(s_mean)
    print(s_max)
    print(s_min)

    print(torch.exp(-1/2 * ((s_mean - S_T[S_T <= s_mean])/ (s_mean - s_min))))
    S_T[S_T <= s_mean] = (torch.exp(-1/2 * ((s_mean - S_T[S_T <= s_mean])/ (s_mean - s_min)))) * S_T[S_T <= s_mean]
    print(S_T)

    print(torch.exp(1/2 * ((S_T[S_T > s_mean] - s_mean) / (s_max - s_mean))))
    S_T[S_T > s_mean] = (torch.exp(((S_T[S_T > s_mean] - s_mean) / (s_max - s_mean)))) * S_T[S_T > s_mean]
    print(S_T)


    # adj = gen_adj(S_T)
    # print(adj)
    # # adj = txt.mm(txt.t())
    # print(adj)
    # F_T = F.normalize(txt, dim=1)
    # S_T = F_T.mm(F_T.t())
    # print(S_T)
    # S_T = S_T * 2 - 1
    # print(S_T)
    # adj = torch.sign(adj)
    # print(adj)
    # adj2triad = sp.csr_matrix(adj)
    # print(adj2triad)

    # model, preprocess = clip.load("ViT-L/14", device="cuda:0")
    # print(model)