import torch
import math
import torch.nn as nn
import torchvision
import clip
from pygcn.layers import GraphConvolution
import torch.nn.functional as F

class ImgNet(nn.Module):
    def __init__(self, code_len):
        super(ImgNet, self).__init__()
        self.clip_image_encode, _ = clip.load("ViT-B/16", device='cuda:0')
        self.hash_layer = nn.Sequential(nn.Linear(512, 4096),
                                        nn.ReLU(inplace=True),
                                        nn.Linear(4096, code_len)
                                        )
        # self.alexnet = torchvision.models.alexnet(pretrained=True)
        # self.fc_encode = nn.Linear(1000, code_len)
        self.alpha = 1.0

    def forward(self, x):
        with torch.no_grad():
            feat_I = self.clip_image_encode.encode_image(x)
            feat_I = feat_I.type(torch.float32)
        hid = self.hash_layer(feat_I)
        # with torch.no_grad():
        #     feat_I = self.alexnet(x)
        # hid = self.fc_encode(feat_I)
        code = torch.tanh(self.alpha * hid)
        return feat_I, code

    def set_alpha(self, epoch):
        self.alpha = math.pow((1.0 * epoch + 1.0), 0.5)


class TxtNet(nn.Module):
    def __init__(self, code_len, txt_feat_len):
        super(TxtNet, self).__init__()
        self.fc1 = nn.Linear(txt_feat_len, 4096)
        self.fc2 = nn.Linear(4096, code_len)
        self.alpha = 1.0

    def forward(self, x):
        feat_T = torch.relu(self.fc1(x))
        hid = self.fc2(feat_T)
        code = torch.tanh(self.alpha * hid)
        return x, code

    def set_alpha(self, epoch):
        self.alpha = math.pow((1.0 * epoch + 1.0), 0.5)


class GCNet_IMG(nn.Module):
    def __init__(self, bit, gamma, batch_size):
        super(GCNet_IMG, self).__init__()

        self.gc1 = GraphConvolution(512, 2048)
        self.gc2 = GraphConvolution(2048, 1024)
        self.linear = nn.Linear(1024, bit)
        self.alpha = 1.0
        self.gamma = gamma
        self.weight = nn.Parameter(torch.FloatTensor(batch_size, batch_size))
        nn.init.kaiming_uniform_(self.weight)

    def forward(self, x, adj):
        adj = adj + self.gamma * self.weight
        x = torch.relu(self.gc1(x, adj))
        x = torch.relu(self.gc2(x, adj))
        x = self.linear(x)
        code = torch.tanh(self.alpha * x)
        return code

    def set_alpha(self, epoch):
        self.alpha = math.pow((1.0 * epoch + 1.0), 0.5)


class GCNet_TXT(nn.Module):
    def __init__(self, txt_feat_len, bit, gamma, batch_size):
        super(GCNet_TXT, self).__init__()

        self.gc1 = GraphConvolution(txt_feat_len, 2048)
        self.gc2 = GraphConvolution(2048, 1024)
        self.linear = nn.Linear(1024, bit)
        self.alpha = 1.0
        self.gamma = gamma
        self.weight = nn.Parameter(torch.FloatTensor(batch_size, batch_size))
        nn.init.kaiming_uniform_(self.weight)

    def forward(self, x, adj):
        adj = adj + self.gamma * self.weight
        x = torch.relu(self.gc1(x, adj))
        x = torch.relu(self.gc2(x, adj))
        x = self.linear(x)
        code = torch.tanh(self.alpha * x)
        return code

    def set_alpha(self, epoch):
        self.alpha = math.pow((1.0 * epoch + 1.0), 0.5)
